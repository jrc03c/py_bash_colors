# Foreground colors


def black(x):
    return "\x1b[30m" + x


def red(x):
    return "\x1b[31m" + x


def green(x):
    return "\x1b[32m" + x


def yellow(x):
    return "\x1b[33m" + x


def blue(x):
    return "\x1b[34m" + x


def magenta(x):
    return "\x1b[35m" + x


def cyan(x):
    return "\x1b[36m" + x


def white(x):
    return "\x1b[37m" + x
