# Background colors


def black(x):
    return "\x1b[40m" + x


def red(x):
    return "\x1b[41m" + x


def green(x):
    return "\x1b[42m" + x


def yellow(x):
    return "\x1b[43m" + x


def blue(x):
    return "\x1b[44m" + x


def magenta(x):
    return "\x1b[45m" + x


def cyan(x):
    return "\x1b[46m" + x


def white(x):
    return "\x1b[47m" + x
